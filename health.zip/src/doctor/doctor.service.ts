import {Injectable} from '@angular/core'
import { IDoctor } from './IDoctor'

import { Observable, observable } from "rxjs";
import { tap } from "rxjs/operators";
import { catchError } from "rxjs/internal/operators/catchError";
import { HttpClient,HttpErrorResponse } from "@angular/common/http";
@Injectable({
    providedIn:'root'
})
export class DoctorService{
   
    doctorUrl = './data/doctor.json';

constructor(private httpser:HttpClient){
    

}
 getDoctors():Observable<IDoctor[]>{
        return this.httpser.get<IDoctor[]>(this.doctorUrl).pipe(
                tap(data=> console.log('doctors:'+JSON.stringify(data))),
            
        )
        

    
    }


   



}