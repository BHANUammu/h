import {Component, OnInit, OnChanges, OnDestroy} from '@angular/core';
import { IDoctor } from './IDoctor';
import {DoctorService} from './../doctor/doctor.service'

@Component({

  selector:'doc-app', 
  templateUrl:'./doctor.component.html',
  
})

export class DoctorComponent implements  OnInit,OnChanges,OnDestroy{

  _doctorSearch: any;
  
  constructor(private docservice:DoctorService){

   
  }
  ngOnInit(): void {
    this.doctors=this.docservice.getDoctors().subscribe(
      // movies=>{
      //   // this.movies=movies;
      //   // this.searchedMovies=this.movies;
      // },
     
    )
   
  }

  ngOnChanges(): void {

  console.log("At the Change detection phase!");  
  }
  ngOnDestroy(): void {
    console.log("Destroying the component");
  }

  imgWidth:number=400;
  imgHeight:number=500;
  docTitle="Top doctors";
  doctors:IDoctor[] = [];
   searchedDoctors:IDoctor[]=[];
  
 
    get doctorSearch():string{
    return this._doctorSearch;
  }
  set doctorSearch(value:string){
    this.doctorSearch=value;
    this.searchedDoctors=this.doctorSearch? this.doctorSearched(this.doctorSearch):this.doctors;
  }
  doctorSearched(search:string):IDoctor[]{
    search=search.toLocaleLowerCase();
    return this.doctors.filter((doctors:IDoctor)=>
    doctors.doctorName.toLocaleLowerCase()==search);
  }
   

  
}